// ignore_for_file: unused_import, unused_element

import 'package:flutter/material.dart';
import 'package:responsi/detail_matches_model.dart';
import 'package:responsi/detail_page.dart';
import 'package:responsi/matches_model.dart';
import 'base_network.dart';
import 'bola_data_source.dart';

class PageDetail extends StatefulWidget {

  final String id;

  const PageDetail({Key? key, required this.id}) : super(key: key);





  @override
  State<PageDetail> createState() => _PageDetailState();
}

class _PageDetailState extends State<PageDetail> {
  bool isFavorite = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
      (isFavorite) ? Colors.pinkAccent.shade100 : Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Flexible(
          child: Text ("Pertandingan ID : ${widget.id}",
          style: TextStyle(
            color: Colors.white,
            )
          )
        ),
        actions: [
          IconButton(
            onPressed: () {
              setState(() {
                isFavorite = !isFavorite;
              });
            },
            icon: (isFavorite)
                ? Icon(Icons.favorite)
                : Icon(Icons.favorite_border),
          ),
        ],
      ),
      body: ListView(
        children: [
          Column(
            children: [
              FutureBuilder(future: DetailMatchesSource.instance.loadDetailMatches(widget.id),
              builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot){
                if (snapshot.hasError){
                  return _buildErrorSection();
                }
                if (snapshot.hasData){
                  DetailMatchesModel detailMatchesModels= DetailMatchesModel.fromJson(snapshot.data);
                  return _buildSuccessSection(detailMatchesModels);
                }
                return _buildLoadingSection();
              },
            )
        ],
      ),
    ],
      ),
    );
  }
Widget _buildErrorSection(){
    return Text("Error");
}
Widget _buildEmptySection(){
    return Text("Empty");
}
Widget _buildLoadingSection(){
    return Center(
      child: CircularProgressIndicator(),
    );
}

Widget _buildSuccessSection (DetailMatchesModel data) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network("https://countryflagsapi.com/png/${data.homeTeam?.name}", width: 200, height: 150,),
            SizedBox(width: 12,),
            Text("${data.homeTeam?.goals}"),
            SizedBox(width: 12,),
            Text(" - "),
            SizedBox(width: 12,),
            Text("${data.awayTeam?.goals}"),
            SizedBox(width: 12,),
            Image.network("https://countryflagsapi.com/png/${data.awayTeam?.name}", width: 200, height: 150,),
          ],
        ),
        SizedBox(height: 5,),
        Text("${data.homeTeam?.name}"),
        SizedBox(height: 10,),
        SizedBox(height: 10,),
        Text("Stadium :  ${data.venue}"),
        SizedBox(height: 5,),
        Text("Location :  ${data.location} "),
        SizedBox(height: 10,),
        Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: Colors.black,
              width: 3,
            ),
            borderRadius: BorderRadius.circular(1)
          ),
          padding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
          margin: EdgeInsets.all(8),
          width: double.infinity,
          height: 300,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
            Text("Statistics", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
            SizedBox(height: 20,),
            Text("${data.homeTeam?.statistics?.ballPossession}Ball Possession${data.awayTeam?.statistics?.ballPossession}"),
            SizedBox(height: 10,),
            Text("${data.homeTeam?.statistics?.attemptsOnGoal}Shot${data.awayTeam?.statistics?.attemptsOnGoal}"),
            SizedBox(height: 10,),
            Text("${data.homeTeam?.statistics?.kicksOnTarget}Shot On Goal${data.awayTeam?.statistics?.kicksOnTarget}"),
            SizedBox(height: 10,),
            Text("${data.homeTeam?.statistics?.corners}Corners${data.awayTeam?.statistics?.corners}"),
            SizedBox(height: 10,),
            Text("${data.homeTeam?.statistics?.offsides}Offside${data.awayTeam?.statistics?.offsides}"),
            SizedBox(height: 10,),
            Text("${data.homeTeam?.statistics?.foulsReceived}Fouls${data.awayTeam?.statistics?.foulsReceived}"),
            SizedBox(height: 10,),
            Text("${data.homeTeam?.statistics?.passesCompleted}Passes Completed${data.awayTeam?.statistics?.passesCompleted}"),
            ],
          ),
        ),
        SizedBox(height: 8,),
        Text("Referees : ", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
        SizedBox(height: 10,),
        Container(
          alignment: Alignment.center,
          width: double.infinity,
          height: 125,
          child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: data.officials?.length,
              itemBuilder: (context, index) {
                return Container(
                  decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.black,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(0)
                  ),
                  margin: EdgeInsets.all(5),
                  width: 100,
                  height: 100,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text("FIFA", style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),),
                      SizedBox(width: 5,),
                      Flexible(
                        child: Text("${data.officials?[index].name}", maxLines: 1,),
                      ),
                      SizedBox(width: 5,),
                      Flexible(
                        child: Text("${data.officials?[index].role}", maxLines: 1,),
                      ),
                    ],
                  ),
                );
              }
          ),
        ),
      ],
    );
}
}