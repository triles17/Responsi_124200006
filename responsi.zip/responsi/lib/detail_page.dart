// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:responsi/page_detail_bola.dart';
import 'package:responsi/matches_model.dart';
import 'bola_data_source.dart';

class DetailPage extends StatefulWidget {
  const DetailPage({Key? key, required String id}) : super(key: key);

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  bool isFavorite = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
      (isFavorite) ? Colors.pinkAccent.shade100 : Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.purpleAccent,
          title: Text("Sepak Bola"),
          actions: [
          IconButton(
          onPressed: () {
    setState(() {
    isFavorite = !isFavorite;
    });
    },
      icon: (isFavorite)
          ? Icon(Icons.favorite)
          : Icon(Icons.favorite_border),
    ),
    ],
      ),
      body: Container(
        padding: EdgeInsets.all(10),
        child: FutureBuilder(
          future: BolaDataSource.instance.loadBola(),
          builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
            if (snapshot.hasError) {
              return _buildErrorSection();
            }
            if (snapshot.hasData) {
              return _buildSuccessSection(snapshot.data);
            }
            return _buildLoadingSection();
          },
        ),
      ),
    );
  }

  Widget _buildErrorSection() {
    return Text("Error");
  }

  Widget _buildSuccessSection(List<dynamic> data) {
    return ListView.builder(
        itemCount: 50,
        itemBuilder: (BuildContext context, int index) {
          MatchesModel matchesModel = MatchesModel.fromJson(data[index]);
          return Container(
            width: double.infinity,
            height: 200,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(
                  onTap: () =>
                      Navigator.push(
                          context, MaterialPageRoute(builder: ((context) {
                        return PageDetail(id: matchesModel.id.toString());
                      })
                      )),
                  child: Card(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.network("https://countryflagsapi.com/png/${matchesModel.homeTeam?.name}", width: 200, height: 150,),
                              SizedBox(width: 12,),
                              Text("${matchesModel.homeTeam?.goals}"),
                              SizedBox(width: 12,),
                              Text(" - "),
                              SizedBox(width: 12,),
                              Text("${matchesModel.awayTeam?.goals}"),
                              SizedBox(width: 12,),
                              Image.network("https://countryflagsapi.com/png/${matchesModel.awayTeam?.name}", width: 200, height: 150,),
                            ],
                          ),
                        ),
                        SizedBox(height: 5,),
                        Text("${matchesModel.homeTeam?.name}")
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        });
  }

  Widget _buildLoadingSection() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }
}



