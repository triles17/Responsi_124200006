// @dart=2.9
// ignore_for_file: unused_import, prefer_const_constructors
// Nama : Tri Lestari
// Nim : 124200006
// kelas : SI-

import 'package:flutter/material.dart';
import 'package:responsi/detail_page.dart';
import 'page_detail_bola.dart';
// import 'src/my_app.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key key}) : super(key: key);

  // This widget is the root of
  // your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Match',
      home: DetailPage(),
    );
  }
}