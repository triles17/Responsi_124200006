// ignore_for_file: unused_import

import 'package:responsi/base_network.dart';
import 'package:responsi/detail_matches_model.dart';
import 'package:responsi/detail_page.dart';

class BolaDataSource {
  static BolaDataSource instance = BolaDataSource();

  Future<List<dynamic>> loadBola() {
    return BaseNetwork.getList("matches");
  }
}
class DetailMatchesSource{
    static DetailMatchesSource instance= DetailMatchesSource();
    Future<Map<String,dynamic>> loadDetailMatches(String id){
      return BaseNetwork.get("matches/${id}");
  }
}